const app = require('./src/app');
const { getDb } = require('./src/db/database');

const PORT = process.env.PORT || 3000;

async function start() {
  await getDb(); // Initialize DB before accepting requests
  app.listen(PORT, () => {
    console.log(`   Internship API running on http://localhost:${PORT}`);
    console.log(`   Health: http://localhost:${PORT}/health`);
    console.log(`   Candidates: http://localhost:${PORT}/candidates`);
  });
}

start().catch(err => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
