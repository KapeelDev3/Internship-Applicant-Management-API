const request = require('supertest');
const app = require('../src/app');
const { setupTestDb } = require('./testHelper');

beforeEach(async () => {
  await setupTestDb();
});

// ─── Seed helper ────────────────────────────────────────────────────────────
const validCandidate = {
  fullName: 'Ali Hassan',
  email: 'ali.hassan@gmail.com',
  university: 'FAST NUCES',
  cgpa: 3.5,
};

async function createCandidate(overrides = {}) {
  return request(app)
    .post('/candidates')
    .send({ ...validCandidate, ...overrides });
}

// ════════════════════════════════════════════════════════════════════════════
// 1. CANDIDATE CREATION
// ════════════════════════════════════════════════════════════════════════════
describe('POST /candidates — Candidate Creation', () => {
  test('creates a candidate with valid data and returns 201', async () => {
    const res = await createCandidate();

    expect(res.status).toBe(201);
    expect(res.body.success).toBe(true);
    expect(res.body.data).toMatchObject({
      fullName: 'Ali Hassan',
      email: 'ali.hassan@gmail.com',
      university: 'FAST NUCES',
      cgpa: 3.5,
      status: 'Applied',
    });
    expect(res.body.data.id).toBeDefined();
    expect(res.body.data.createdAt).toBeDefined();
  });

  test('returns 400 when fullName is empty', async () => {
    const res = await createCandidate({ fullName: '' });
    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.errors).toEqual(expect.arrayContaining([expect.stringContaining('fullName')]));
  });

  test('returns 400 when email is invalid', async () => {
    const res = await createCandidate({ email: 'not-an-email' });
    expect(res.status).toBe(400);
    expect(res.body.errors).toEqual(expect.arrayContaining([expect.stringContaining('email')]));
  });

  test('returns 400 when cgpa is above 4', async () => {
    const res = await createCandidate({ cgpa: 4.5 });
    expect(res.status).toBe(400);
    expect(res.body.errors).toEqual(expect.arrayContaining([expect.stringContaining('cgpa')]));
  });

  test('returns 400 when cgpa is negative', async () => {
    const res = await createCandidate({ cgpa: -1 });
    expect(res.status).toBe(400);
  });

  test('returns 400 when status is invalid', async () => {
    const res = await createCandidate({ status: 'Pending' });
    expect(res.status).toBe(400);
    expect(res.body.errors).toEqual(expect.arrayContaining([expect.stringContaining('status')]));
  });

  test('returns 400 when university is missing', async () => {
    const { university, ...rest } = validCandidate;
    const res = await createCandidate({ ...rest, university: '' });
    expect(res.status).toBe(400);
  });

  test('returns 409 on duplicate email', async () => {
    await createCandidate();
    const res = await createCandidate({ fullName: 'Ahmed Ali' }); // same email
    expect(res.status).toBe(409);
    expect(res.body.errors).toEqual(expect.arrayContaining([expect.stringContaining('already exists')]));
  });

  test('accepts a custom valid status', async () => {
    const res = await createCandidate({ status: 'Shortlisted' });
    expect(res.status).toBe(201);
    expect(res.body.data.status).toBe('Shortlisted');
  });

  test('email is normalised to lowercase', async () => {
  const res = await createCandidate({ email: 'ALI.HASSAN@GMAIL.COM' });
    expect(res.status).toBe(201);
    expect(res.body.data.email).toBe('ali.hassan@gmail.com');
  });
});

// ════════════════════════════════════════════════════════════════════════════
// 2. CANDIDATE RETRIEVAL
// ════════════════════════════════════════════════════════════════════════════
describe('GET /candidates — Candidate Retrieval', () => {
  test('returns empty list when no candidates exist', async () => {
    const res = await request(app).get('/candidates');
    expect(res.status).toBe(200);
    expect(res.body.data).toHaveLength(0);
    expect(res.body.count).toBe(0);
  });

  test('returns all candidates', async () => {
    await createCandidate({ email: 'a@test.com' });
    await createCandidate({ email: 'b@test.com', fullName: 'Sara Khan' });

    const res = await request(app).get('/candidates');
    expect(res.status).toBe(200);
    expect(res.body.data).toHaveLength(2);
    expect(res.body.count).toBe(2);
  });

  test('filters candidates by status', async () => {
    await createCandidate({ email: 'a@test.com', status: 'Applied' });
    await createCandidate({ email: 'b@test.com', status: 'Shortlisted' });

    const res = await request(app).get('/candidates?status=Shortlisted');
    expect(res.status).toBe(200);
    expect(res.body.data).toHaveLength(1);
    expect(res.body.data[0].status).toBe('Shortlisted');
  });
});

describe('GET /candidates/:id — Get Candidate By ID', () => {
  test('returns the correct candidate by id', async () => {
    const create = await createCandidate();
    const { id } = create.body.data;

    const res = await request(app).get(`/candidates/${id}`);
    expect(res.status).toBe(200);
    expect(res.body.data.id).toBe(id);
    expect(res.body.data.fullName).toBe('Ali Hassan');
  });

  test('returns 404 for a non-existent id', async () => {
    const res = await request(app).get('/candidates/non-existent-id');
    expect(res.status).toBe(404);
    expect(res.body.success).toBe(false);
  });
});

// ════════════════════════════════════════════════════════════════════════════
// 3. STATUS UPDATE
// ════════════════════════════════════════════════════════════════════════════
describe('PUT /candidates/:id/status — Status Update', () => {
  test('updates status from Applied to Shortlisted', async () => {
    const create = await createCandidate();
    const { id } = create.body.data;

    const res = await request(app)
      .put(`/candidates/${id}/status`)
      .send({ status: 'Shortlisted' });

    expect(res.status).toBe(200);
    expect(res.body.data.status).toBe('Shortlisted');
  });

  test('updates status through full workflow', async () => {
    const create = await createCandidate();
    const { id } = create.body.data;

    const statuses = ['Shortlisted', 'Interviewed', 'Selected'];
    for (const status of statuses) {
      const res = await request(app).put(`/candidates/${id}/status`).send({ status });
      expect(res.status).toBe(200);
      expect(res.body.data.status).toBe(status);
    }
  });

  test('returns 400 for an invalid status', async () => {
    const create = await createCandidate();
    const { id } = create.body.data;

    const res = await request(app)
      .put(`/candidates/${id}/status`)
      .send({ status: 'Pending' });

    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
  });

  test('returns 400 when status is missing', async () => {
    const create = await createCandidate();
    const { id } = create.body.data;

    const res = await request(app).put(`/candidates/${id}/status`).send({});
    expect(res.status).toBe(400);
  });

  test('returns 404 when updating status for non-existent candidate', async () => {
    const res = await request(app)
      .put('/candidates/does-not-exist/status')
      .send({ status: 'Selected' });
    expect(res.status).toBe(404);
  });
});

// ════════════════════════════════════════════════════════════════════════════
// 4. DELETE
// ════════════════════════════════════════════════════════════════════════════
describe('DELETE /candidates/:id — Delete Candidate', () => {
  test('deletes an existing candidate', async () => {
    const create = await createCandidate();
    const { id } = create.body.data;

    const del = await request(app).delete(`/candidates/${id}`);
    expect(del.status).toBe(200);
    expect(del.body.success).toBe(true);

    // Confirm it's gone
    const get = await request(app).get(`/candidates/${id}`);
    expect(get.status).toBe(404);
  });

  test('returns 404 when deleting a non-existent candidate', async () => {
    const res = await request(app).delete('/candidates/ghost-id');
    expect(res.status).toBe(404);
  });
});

// ════════════════════════════════════════════════════════════════════════════
// 5. HEALTH CHECK
// ════════════════════════════════════════════════════════════════════════════
describe('GET /health', () => {
  test('returns 200 with status ok', async () => {
    const res = await request(app).get('/health');
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('ok');
  });
});
