const initSqlJs = require('sql.js');
const dbModule = require('../src/db/database');

async function setupTestDb() {
  const SQL = await initSqlJs();
  const testDb = new SQL.Database();

  testDb.run(`
    CREATE TABLE IF NOT EXISTS candidates (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      fullName   TEXT NOT NULL,
      email      TEXT NOT NULL UNIQUE,
      university TEXT NOT NULL,
      cgpa       REAL NOT NULL,
      status     TEXT NOT NULL DEFAULT 'Applied',
      createdAt  TEXT NOT NULL,
      updatedAt  TEXT NOT NULL
    )
  `);

  dbModule._setDb(testDb);
}

module.exports = { setupTestDb };
