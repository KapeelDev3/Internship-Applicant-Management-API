const express = require('express');
const candidatesRouter = require('./routes/candidates');

const app = express();

app.use(express.json());

// ✅ Root route — Welcome message
app.get('/', (req, res) => {
  res.json({
    success: true,
    message: 'Welcome to Internship Applicant Management API',
    version: '1.0.0',
    endpoints: {
      health:           'GET    /health',
      createCandidate:  'POST   /candidates',
      getAllCandidates:  'GET    /candidates',
      getCandidateById: 'GET    /candidates/:id',
      updateStatus:     'PUT    /candidates/:id/status',
      deleteCandidate:  'DELETE /candidates/:id',
    }
  });
});

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Routes
app.use('/candidates', candidatesRouter);

// 404 handler
app.use((req, res) => {
  res.status(404).json({ success: false, errors: [`Route ${req.method} ${req.path} not found.`] });
});

// Global error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ success: false, errors: ['An unexpected error occurred.'] });
});

module.exports = app;