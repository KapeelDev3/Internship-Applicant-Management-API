const VALID_STATUSES = ['Applied', 'Shortlisted', 'Interviewed', 'Selected', 'Rejected'];

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function validateCreateCandidate(req, res, next) {
  const { fullName, email, university, cgpa, status } = req.body;
  const errors = [];

  if (!fullName || typeof fullName !== 'string' || fullName.trim() === '') {
    errors.push('fullName is required and cannot be empty.');
  }

  if (!email || !isValidEmail(email)) {
    errors.push('A valid email address is required.');
  }

  if (!university || typeof university !== 'string' || university.trim() === '') {
    errors.push('university is required and cannot be empty.');
  }

  const cgpaNum = parseFloat(cgpa);
  if (cgpa === undefined || cgpa === null || cgpa === '' || isNaN(cgpaNum) || cgpaNum < 0 || cgpaNum > 4) {
    errors.push('cgpa must be a number between 0 and 4.');
  }

  if (status !== undefined && !VALID_STATUSES.includes(status)) {
    errors.push(`status must be one of: ${VALID_STATUSES.join(', ')}.`);
  }

  if (errors.length > 0) {
    return res.status(400).json({ success: false, errors });
  }

  next();
}

function validateUpdateStatus(req, res, next) {
  const { status } = req.body;

  if (!status) {
    return res.status(400).json({ success: false, errors: ['status is required.'] });
  }

  if (!VALID_STATUSES.includes(status)) {
    return res.status(400).json({
      success: false,
      errors: [`status must be one of: ${VALID_STATUSES.join(', ')}.`],
    });
  }

  next();
}

module.exports = { validateCreateCandidate, validateUpdateStatus, VALID_STATUSES };
