const initSqlJs = require('sql.js');
const path = require('path');
const fs = require('fs');

const DB_PATH = path.join(__dirname, '../../data/internship.sqlite');
const state = { db: null };

async function getDb() {
  if (state.db) return state.db;

  const SQL = await initSqlJs();

  const dir = path.dirname(DB_PATH);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

  if (fs.existsSync(DB_PATH)) {
    const fileBuffer = fs.readFileSync(DB_PATH);
    state.db = new SQL.Database(fileBuffer);
  } else {
    state.db = new SQL.Database();
  }

  state.db.run(`
    CREATE TABLE IF NOT EXISTS candidates (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      fullName   TEXT NOT NULL,
      email      TEXT NOT NULL UNIQUE,
      university TEXT NOT NULL,
      cgpa       REAL NOT NULL,
      status     TEXT NOT NULL DEFAULT 'Applied',
      createdAt  TEXT NOT NULL,
      updatedAt  TEXT NOT NULL
    )
  `);

  _persist();
  return state.db;
}

function _persist() {
  if (!state.db) return;
  try {
    const data = state.db.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));
  } catch (_) {}
}

// Run a write statement, returns last inserted numeric ID
async function run(sql, params = []) {
  const db = await getDb();
  db.run(sql, params);
  const result = db.exec('SELECT last_insert_rowid() as id');
  const lastId = result[0]?.values[0][0] ?? null;
  _persist();
  return lastId;  
}

async function all(sql, params = []) {
  const db = await getDb();
  const stmt = db.prepare(sql);
  stmt.bind(params);
  const rows = [];
  while (stmt.step()) rows.push(stmt.getAsObject());
  stmt.free();
  return rows;
}

async function get(sql, params = []) {
  const rows = await all(sql, params);
  return rows[0] || null;
}

function _setDb(testDb) {
  state.db = testDb;
}

module.exports = { getDb, run, all, get, _setDb };
