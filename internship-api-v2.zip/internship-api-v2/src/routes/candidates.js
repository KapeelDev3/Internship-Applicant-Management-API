const express = require('express');
const { run, all, get } = require('../db/database');
const { validateCreateCandidate, validateUpdateStatus } = require('../middleware/validation');

const router = express.Router();

// POST /candidates
router.post('/', validateCreateCandidate, async (req, res) => {
  try {
    const { id, fullName, email, university, cgpa, status = 'Applied' } = req.body;

    const existing = await get('SELECT id FROM candidates WHERE email = ?', [email.toLowerCase()]);
    if (existing) {
      return res.status(409).json({ success: false, errors: ['A candidate with this email already exists.'] });
    }

    const now = new Date().toISOString();
    const newId = await run(
      `INSERT INTO candidates (fullName, email, university, cgpa, status, createdAt, updatedAt)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [fullName.trim(), email.toLowerCase().trim(), university.trim(), parseFloat(cgpa), status, now, now]
    );

    const candidate = await get('SELECT * FROM candidates WHERE id = ?', [newId]);
    return res.status(201).json({ success: true, data: candidate });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, errors: ['Failed to create candidate.'] });
  }
});

// GET /candidates
router.get('/', async (req, res) => {
  try {
    const { status, university, sortBy = 'id', order = 'asc' } = req.query;

    const allowedSortFields = ['id', 'fullName', 'cgpa', 'status', 'createdAt', 'updatedAt'];
    const sortField = allowedSortFields.includes(sortBy) ? sortBy : 'id';
    const sortOrder = order.toLowerCase() === 'desc' ? 'DESC' : 'ASC';

    let sql = 'SELECT * FROM candidates WHERE 1=1';
    const params = [];

    if (status) { sql += ' AND status = ?'; params.push(status); }
    if (university) { sql += ' AND LOWER(university) LIKE ?'; params.push(`%${university.toLowerCase()}%`); }

    sql += ` ORDER BY ${sortField} ${sortOrder}`;

    const candidates = await all(sql, params);
    return res.json({ success: true, count: candidates.length, data: candidates });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, errors: ['Failed to fetch candidates.'] });
  }
});

// GET /candidates/:id
router.get('/:id', async (req, res) => {
  try {
    const candidate = await get('SELECT * FROM candidates WHERE id = ?', [req.params.id]);
    if (!candidate) {
      return res.status(404).json({ success: false, errors: ['Candidate not found.'] });
    }
    return res.json({ success: true, data: candidate });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, errors: ['Failed to fetch candidate.'] });
  }
});

// PUT /candidates/:id/status
router.put('/:id/status', validateUpdateStatus, async (req, res) => {
  try {
    const candidate = await get('SELECT * FROM candidates WHERE id = ?', [req.params.id]);
    if (!candidate) {
      return res.status(404).json({ success: false, errors: ['Candidate not found.'] });
    }

    const now = new Date().toISOString();
    await run('UPDATE candidates SET status = ?, updatedAt = ? WHERE id = ?', [req.body.status, now, req.params.id]);

    const updated = await get('SELECT * FROM candidates WHERE id = ?', [req.params.id]);
    return res.json({ success: true, data: updated });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, errors: ['Failed to update status.'] });
  }
});

// DELETE /candidates/:id
router.delete('/:id', async (req, res) => {
  try {
    const candidate = await get('SELECT * FROM candidates WHERE id = ?', [req.params.id]);
    if (!candidate) {
      return res.status(404).json({ success: false, errors: ['Candidate not found.'] });
    }
    await run('DELETE FROM candidates WHERE id = ?', [req.params.id]);
    return res.json({ success: true, message: 'Candidate deleted successfully.' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ success: false, errors: ['Failed to delete candidate.'] });
  }
});

module.exports = router;
